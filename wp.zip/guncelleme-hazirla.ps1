# PDF Roket - GitHub'a yuklenecek guncelleme paketini hazirlar
# 1) Surum numarasini 1 artirir  2) wp.zip olusturur (electron klasoru ve gereksiz dosyalar HARIC)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$verFile = Join-Path $root 'app\appversion.txt'
$cur = 0
if (Test-Path $verFile) { [void][int]::TryParse(((Get-Content -Raw $verFile).Trim()), [ref]$cur) }
$new = $cur + 1
[IO.File]::WriteAllText($verFile, [string]$new)
[IO.File]::WriteAllText((Join-Path $root 'appversion.txt'), [string]$new)
Write-Host ("Surum: {0} -> {1}" -f $cur, $new)

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$out = Join-Path $root 'wp.zip'
if (Test-Path $out) { Remove-Item $out -Force }

$skipDirs  = @('electron', 'electron_tmp', '_indirme', 'app_yedek', '.git')
$skipFiles = @('wp.zip', 'kurulum-log.txt', 'guncelleme-hazirla.ps1', 'guncelleme-hazirla.bat', 'appversion.txt')

$zip = [IO.Compression.ZipFile]::Open($out, 'Create')
try {
  Get-ChildItem -Path $root -Recurse -File -Force | ForEach-Object {
    $rel = $_.FullName.Substring($root.Length).TrimStart('\', '/')
    $top = ($rel -split '[\\/]')[0]
    if ($skipDirs -contains $top) { return }
    if (($rel -notmatch '[\\/]') -and ($skipFiles -contains $rel)) { return }
    if ($_.Name -eq '.unblocked' -or $_.Extension -eq '.lnk') { return }
    $name = $rel -replace '\\', '/'
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $name, [IO.Compression.CompressionLevel]::Optimal)
  }
} finally { $zip.Dispose() }

$mb = [math]::Round((Get-Item $out).Length / 1MB, 1)
Write-Host ''
Write-Host ("HAZIR: wp.zip ({0} MB), surum {1}" -f $mb, $new) -ForegroundColor Green
Write-Host ''
Write-Host 'Simdi GitHub (kendineselam/wp, main dali) icine su 2 dosyayi yukle / uzerine yaz:'
Write-Host '   1) wp.zip'
Write-Host ("   2) appversion.txt   (icinde sadece {0} yazar)" -f $new)
Write-Host 'Istersen "ne degisti" notu icin appnotes.txt de yukleyebilirsin (kullanicilara gosterilir).'
Write-Host 'ONEMLI: yuklemeden once kendi bilgisayarinda calistigini dene!'
if ($mb -gt 90) { Write-Host 'UYARI: GitHub 100 MB ustu dosyayi kabul etmez, zip cok buyuk.' -ForegroundColor Yellow }
