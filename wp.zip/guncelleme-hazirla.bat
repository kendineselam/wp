@echo off
cd /d "%~dp0"
title Guncelleme paketi hazirla
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0guncelleme-hazirla.ps1"
if errorlevel 1 echo Bir sorun olustu.
pause
