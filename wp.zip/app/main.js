const { app, BrowserWindow, Menu, shell, session, ipcMain, net, Tray, dialog, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const vm = require('vm');

const WA_URL = 'https://web.whatsapp.com/';
const START_URL = process.env.PDFROKET_TEST_URL || WA_URL;
const PARTITION = 'persist:whatsapp';
const ALLOWED_PERMS = ['notifications', 'clipboard-sanitized-write', 'media', 'fullscreen', 'clipboard-read'];

app.setAppUserModelId('local.pdfroket.desktop');

// ---------------- GitHub'dan otomatik guncelleme (content.js) ----------------
const UPDATE_BASE = 'https://raw.githubusercontent.com/kendineselam/wp/main/';
const upDir = () => path.join(app.getPath('userData'), 'update');
const readNum = (p) => { try { const n = parseInt(fs.readFileSync(p, 'utf8').trim(), 10); return Number.isFinite(n) ? n : 0; } catch (e) { return 0; } };

// Hangi content.js kullanilacak: guncellenmis kopya zip'tekinden yeniyse o, degilse zip'taki
function currentSource() {
  const bundledVer = readNum(path.join(__dirname, 'version.txt'));
  let cachedVer = 0, cachedCode = null;
  try {
    cachedVer = readNum(path.join(upDir(), 'version.txt'));
    const c = fs.readFileSync(path.join(upDir(), 'content.js'), 'utf8');
    if (c.length > 1000) cachedCode = c; else cachedVer = 0;
  } catch (e) { cachedVer = 0; }
  if (cachedCode && cachedVer > bundledVer) return { version: cachedVer, code: cachedCode };
  return { version: bundledVer, code: fs.readFileSync(path.join(__dirname, 'content.js'), 'utf8') };
}

ipcMain.on('pr:code', (e) => { try { e.returnValue = currentSource().code; } catch (err) { e.returnValue = ''; } });
// Guncel kopya hata verirse sil, bir sonraki acilista zip'teki calisan surum kullanilir
ipcMain.on('pr:bad', () => { try { fs.rmSync(upDir(), { recursive: true, force: true }); } catch (e) {} });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------- Logo secimi (PDF Roket / WhatsApp / Karma / Ozel dosya) ----------------
try { app.setAppUserModelId('com.pdfroket.whatsapp'); } catch (e) {}
const LOGOS = {
  roket:    { label: 'PDF Roket logosu',      png: 'icons/roket.png',    ico: 'icons/roket.ico' },
  whatsapp: { label: 'WhatsApp logosu',       png: 'icons/whatsapp.png', ico: 'icons/whatsapp.ico' },
  karma:    { label: 'WhatsApp + Roket logosu', png: 'icons/karma.png',  ico: 'icons/karma.ico' }
};
const settingsPath = () => path.join(app.getPath('userData'), 'settings.json');
function readSettings() { try { return JSON.parse(fs.readFileSync(settingsPath(), 'utf8')) || {}; } catch (e) { return {}; } }
function writeSettings(o) { try { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.writeFileSync(settingsPath(), JSON.stringify(o), 'utf8'); } catch (e) {} }

// Secili logonun dosya yolu (png/ico). Sorun varsa varsayilan: roket
function logoFile() {
  const st = readSettings();
  if (st.logo === 'custom' && st.customFile) {
    const f = path.join(app.getPath('userData'), st.customFile);
    if (fs.existsSync(f) && !nativeImage.createFromPath(f).isEmpty()) return f;
  }
  const l = LOGOS[st.logo] || LOGOS.roket;
  return path.join(__dirname, l.png);
}
const logoImage = () => nativeImage.createFromPath(logoFile());

// Secili logonun .ico yolu (kisayol + gorev cubugu icin). Yoksa undefined.
function logoIco() {
  try {
    const st = readSettings();
    if (st.logo === 'custom') {
      const f = path.join(app.getPath('userData'), 'custom-logo.ico');
      return fs.existsSync(f) ? f : undefined;
    }
    return path.join(__dirname, (LOGOS[st.logo] || LOGOS.roket).ico);
  } catch (e) { return undefined; }
}
// Herhangi bir resmi 256x256 PNG iceren .ico dosyasina cevirir
function writeIcoFromImage(img, dest) {
  const png = img.resize({ width: 256, height: 256 }).toPNG();
  const head = Buffer.alloc(22);
  head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(1, 4);
  head[6] = 0; head[7] = 0; head[8] = 0; head[9] = 0;
  head.writeUInt16LE(1, 10); head.writeUInt16LE(32, 12);
  head.writeUInt32LE(png.length, 14); head.writeUInt32LE(22, 18);
  fs.writeFileSync(dest, Buffer.concat([head, png]));
}

// Kisayollarin ikonunu guncelle: masaustu + gorev cubuguna sabitlenmis kisayol(lar)
function updateShortcutIcon() {
  if (process.platform !== 'win32') return;
  const ico = logoIco();
  if (!ico) return;
  const exeDir = path.dirname(process.execPath).toLowerCase();
  const args = '"' + app.getAppPath() + '"';
  let changed = false;
  const upd = (lnk, fixArgs) => {
    try {
      if (!fs.existsSync(lnk)) return;
      const o = { icon: ico, iconIndex: 0 };
      if (fixArgs) { o.args = args; o.cwd = app.getAppPath(); }
      shell.writeShortcutLink(lnk, 'update', o);
      changed = true;
    } catch (e) {}
  };
  upd(path.join(app.getPath('desktop'), 'PDF Roket WhatsApp.lnk'), false);
  try {
    const pinDir = path.join(app.getPath('appData'), 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar');
    for (const f of fs.readdirSync(pinDir)) {
      if (!/\.lnk$/i.test(f)) continue;
      const lnk = path.join(pinDir, f);
      try {
        const t = shell.readShortcutLink(lnk).target || '';
        if (path.dirname(t).toLowerCase() === exeDir && /^(electron|pdf roket whatsapp)\.exe$/i.test(path.basename(t))) upd(lnk, true);
      } catch (e) {}
    }
  } catch (e) {}
  if (changed) {
    try { require('child_process').spawn('ie4uinit.exe', ['-show'], { detached: true, stdio: 'ignore', windowsHide: true }).on('error', () => {}).unref(); } catch (e) {}
  }
}
// Pencerenin gorev cubugu bilgisi: sabitlenince dogru ikon + dogru komutla acilsin
function applyAppDetails() {
  if (process.platform !== 'win32' || !mainWin || mainWin.isDestroyed()) return;
  try {
    const d = {
      appId: 'com.pdfroket.whatsapp',
      relaunchCommand: '"' + process.execPath + '" "' + app.getAppPath() + '"',
      relaunchDisplayName: 'PDF Roket WhatsApp'
    };
    const ico = logoIco();
    if (ico) { d.appIconPath = ico; d.appIconIndex = 0; }
    mainWin.setAppDetails(d);
  } catch (e) {}
}

let tray = null, mainWin = null;
function applyLogo() {
  const img = logoImage();
  if (img.isEmpty()) return;
  if (mainWin && !mainWin.isDestroyed()) mainWin.setIcon(img);
  applyAppDetails();
  if (tray && !tray.isDestroyed()) tray.setImage(img.resize({ width: 32, height: 32 }));
  updateShortcutIcon();
}
function setLogo(key) {
  const st = readSettings(); st.logo = key; writeSettings(st);
  applyLogo(); refreshMenus();
}
async function pickCustomLogo() {
  const r = await dialog.showOpenDialog(mainWin && !mainWin.isDestroyed() ? mainWin : undefined, {
    title: 'Uygulama logosu sec', properties: ['openFile'],
    filters: [{ name: 'Resim (PNG, ICO, JPG)', extensions: ['png', 'ico', 'jpg', 'jpeg'] }]
  });
  if (r.canceled || !r.filePaths[0]) return;
  const src = r.filePaths[0];
  if (nativeImage.createFromPath(src).isEmpty()) { dialog.showErrorBox('Logo', 'Bu dosya resim olarak okunamadi.'); return; }
  try {
    const name = 'custom-logo' + path.extname(src).toLowerCase();
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.copyFileSync(src, path.join(app.getPath('userData'), name));
    try { writeIcoFromImage(nativeImage.createFromPath(src), path.join(app.getPath('userData'), 'custom-logo.ico')); } catch (e) {}
    const st = readSettings(); st.logo = 'custom'; st.customFile = name; writeSettings(st);
    applyLogo(); refreshMenus();
  } catch (e) { dialog.showErrorBox('Logo', 'Logo kaydedilemedi: ' + e.message); }
}
function logoMenuItems() {
  const cur = readSettings().logo || 'roket';
  const items = Object.keys(LOGOS).map((k) => ({ label: LOGOS[k].label, type: 'radio', checked: cur === k, click: () => setLogo(k) }));
  items.push({ label: 'Özel logo seç...', type: 'radio', checked: cur === 'custom', click: () => pickCustomLogo() });
  return items;
}
function buildAppMenu() {
  try {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { label: 'Logo', submenu: logoMenuItems() },
      { label: 'Düzenle', submenu: [
        { role: 'undo', label: 'Geri al' }, { role: 'redo', label: 'Yinele' }, { type: 'separator' },
        { role: 'cut', label: 'Kes' }, { role: 'copy', label: 'Kopyala' }, { role: 'paste', label: 'Yapıştır' }, { role: 'selectAll', label: 'Tümünü seç' }
      ] },
      { label: 'Görünüm', submenu: [
        { role: 'reload', label: 'Yenile' }, { type: 'separator' },
        { role: 'zoomIn', label: 'Yakınlaştır' }, { role: 'zoomOut', label: 'Uzaklaştır' }, { role: 'resetZoom', label: 'Yakınlaştırmayı sıfırla' },
        { type: 'separator' }, { role: 'togglefullscreen', label: 'Tam ekran' }
      ] },
      { label: 'Çık', click: () => app.quit() }
    ]));
  } catch (e) { console.error('[PDF-ROKET] menu olusturulamadi:', e.message); }
}
function refreshMenus() { buildTrayMenu(); buildAppMenu(); }
function buildTrayMenu() {
  if (!tray || tray.isDestroyed()) return;
  const items = logoMenuItems();
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Uygulama logosu', enabled: false },
    ...items,
    { type: 'separator' },
    { label: 'Pencereyi göster', click: () => { if (mainWin && !mainWin.isDestroyed()) { if (mainWin.isMinimized()) mainWin.restore(); mainWin.show(); mainWin.focus(); } } },
    { label: 'Çık', click: () => app.quit() }
  ]));
}
function createTray() {
  try {
    const img = logoImage();
    if (img.isEmpty()) return;
    tray = new Tray(img.resize({ width: 32, height: 32 }));
    tray.setToolTip('PDF Roket WhatsApp  (sağ tık: logo değiştir)');
    tray.on('click', () => { if (mainWin && !mainWin.isDestroyed()) { if (mainWin.isMinimized()) mainWin.restore(); mainWin.show(); mainWin.focus(); } });
    buildTrayMenu();
  } catch (e) { console.error('[PDF-ROKET] tray olusturulamadi:', e.message); }
}

// Donen durum: 'yok' (yeni surum yok) | 'guncellendi' | 'cevrimdisi' | 'hata'
async function checkUpdate(onFound) {
  try {
    const t = Date.now();
    const opts = { cache: 'no-store', signal: AbortSignal.timeout(7000) };
    const r = await net.fetch(UPDATE_BASE + 'version.txt?t=' + t, opts);
    if (!r.ok) return { status: 'hata' };
    const remote = parseInt((await r.text()).trim(), 10);
    if (!Number.isFinite(remote)) return { status: 'hata' };
    if (remote <= currentSource().version) return { status: 'yok', version: currentSource().version };

    if (onFound) await onFound(remote);
    const r2 = await net.fetch(UPDATE_BASE + 'content.js?t=' + t, { cache: 'no-store', signal: AbortSignal.timeout(15000) });
    if (!r2.ok) return { status: 'hata' };
    const code = await r2.text();
    if (code.length < 1000 || !code.includes('PDF-ROKET')) return { status: 'hata' };
    new vm.Script(code);                       // sozdizimi hatasi varsa kaydetme

    fs.mkdirSync(upDir(), { recursive: true });
    fs.writeFileSync(path.join(upDir(), 'content.js'), code, 'utf8');
    fs.writeFileSync(path.join(upDir(), 'version.txt'), String(remote), 'utf8');
    console.log('[PDF-ROKET] guncellendi -> surum ' + remote);
    return { status: 'guncellendi', version: remote };
  } catch (e) {
    console.error('[PDF-ROKET] guncelleme kontrolu yapilamadi:', e.message);
    return { status: 'cevrimdisi' };
  }
}

// ---------------- Acilis ekrani ----------------
function createSplash() {
  const sp = new BrowserWindow({
    width: 440, height: 280, frame: false, resizable: false, center: true, show: false,
    alwaysOnTop: true, backgroundColor: '#111b21', icon: logoImage(),
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });
  let logoUrl = '';
  try { logoUrl = logoImage().resize({ width: 72, height: 72 }).toDataURL(); } catch (e) {}
  const logoHtml = logoUrl ? `<img src="${logoUrl}" style="width:64px;height:64px">` : '🚀';
  const html = `<!doctype html><meta charset="utf-8"><body style="margin:0;height:100vh;box-sizing:border-box;border:1px solid #2a3942;background:#111b21;color:#e9edef;font-family:Segoe UI,Arial,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;user-select:none;-webkit-app-region:drag">
<div style="font-size:54px;line-height:1">${logoHtml}</div>
<div style="font-size:22px;font-weight:700;margin-top:10px">PDF Roket <span style="color:#25D366">WhatsApp</span></div>
<div id="m" style="margin:22px 24px 0;font-size:15px;min-height:42px;line-height:1.4">Başlatılıyor...</div>
<div id="sp" style="width:30px;height:30px;margin-top:14px;border:3px solid #2a3942;border-top-color:#25D366;border-radius:50%;animation:r .8s linear infinite"></div>
<div id="v" style="position:absolute;bottom:10px;font-size:11px;color:#667781"></div>
<div style="position:absolute;bottom:8px;right:14px;font-size:14px;color:#8696a0;font-family:'Segoe Script','Brush Script MT',cursive;font-style:italic;letter-spacing:.3px">Yasin Çelik</div>
<div style="position:absolute;left:0;right:0;bottom:0;height:3px;background:#1f2c34"><div style="height:100%;width:0;background:#25D366;animation:b 5.2s linear forwards"></div></div>
<style>@keyframes r{to{transform:rotate(360deg)}}@keyframes b{to{width:100%}}</style></body>`;
  sp.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).catch(() => {});
  sp.once('ready-to-show', () => sp.show());
  return sp;
}
async function splashMsg(sp, text, spin = true) {
  if (!sp || sp.isDestroyed()) return;
  try {
    await sp.webContents.executeJavaScript(
      `document.getElementById('m').textContent=${JSON.stringify(text)};document.getElementById('sp').style.display=${spin ? "'block'" : "'none'"};`);
  } catch (e) {}
}

async function startup() {
  const sp = createSplash();
  const splashStart = Date.now();
  await sleep(400);
  try { await sp.webContents.executeJavaScript(`document.getElementById('v').textContent=${JSON.stringify('Sürüm ' + currentSource().version)}`); } catch (e) {}
  await splashMsg(sp, 'Güncellemeler kontrol ediliyor...');
  const t0 = Date.now();

  const res = await checkUpdate(async (v) => {
    await splashMsg(sp, 'Aha! Yeni güncelleme var 👀 Hemen indiriyorum hehehe 😈');
    await sleep(1400);
  });
  // en az 1 sn "kontrol ediliyor" gorunsun
  if (Date.now() - t0 < 2500) await sleep(2500 - (Date.now() - t0));

  // Guncelleme bitti: WhatsApp'i arka planda hemen yuklemeye basla (acilis ekrani sirasinda)
  const win = createWindow();

  if (res.status === 'guncellendi') {
    await splashMsg(sp, 'Güncelleme tamam! 🎉 Sürüm ' + res.version + ' hazır, açılıyor...', false);
    await sleep(2000);
  } else if (res.status === 'yok') {
    await splashMsg(sp, 'Yeni sürüm yok, her şey güncel ✅ İşimize bakalım 😎', false);
    await sleep(2000);
  } else {
    await splashMsg(sp, 'Güncelleme kontrol edilemedi (internet yok mu?) 🤷 Mevcut sürümle devam ediyoruz.', false);
    await sleep(2200);
  }
  // acilis ekrani toplamda en az 5 sn acik kalsin
  const spent = Date.now() - splashStart;
  if (spent < 5200) await sleep(5200 - spent);
  if (!sp.isDestroyed()) sp.close();
  if (win && !win.isDestroyed()) { win.show(); win.focus(); }
}

// WhatsApp Web "tarayici desteklenmiyor" demesin diye Electron izini sil
function chromeUA() {
  return app.userAgentFallback
    .replace(/\s(Electron|pdf-roket-masaustu)\/\S+/g, '')
    .trim();
}

const OFFLINE_HTML = `<!doctype html><meta charset="utf-8"><title>PDF Roket WhatsApp</title>
<body style="margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#111b21;color:#e9edef;font-family:Segoe UI,sans-serif;text-align:center">
<div><div style="font-size:48px">📡</div><h2>WhatsApp'a ulasilamiyor</h2>
<p>Internet baglantini kontrol et. Baglanti gelince otomatik yenilenecek.</p>
<button onclick="location.href='${WA_URL}'" style="padding:10px 22px;border:0;border-radius:8px;background:#25D366;color:#fff;font-size:15px;font-weight:bold;cursor:pointer">Simdi dene</button></div>
<script>setTimeout(function(){location.href='${WA_URL}'},5000)</script></body>`;

function createWindow() {
  const ses = session.fromPartition(PARTITION);
  const ua = chromeUA();
  ses.setUserAgent(ua);

  ses.setPermissionRequestHandler((wc, perm, cb) => cb(ALLOWED_PERMS.includes(perm)));
  ses.setPermissionCheckHandler((wc, perm) => ALLOWED_PERMS.includes(perm));

  buildAppMenu();
  const win = new BrowserWindow({
    show: false,            // acilis ekrani bitince gosterilir (WhatsApp arka planda yuklenir)
    width: 1280,
    height: 860,
    minWidth: 800,
    minHeight: 500,
    icon: logoImage(),
    autoHideMenuBar: false,
    backgroundColor: '#111b21',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,           // preload dosya okuyabilsin
      partition: PARTITION      // QR girisi kalici olsun
    }
  });
  win.webContents.setUserAgent(ua);

  // blob: (PDF "yeni sekmede ac") uygulama icinde yeni pencerede acilsin, diger linkler tarayicida
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('blob:')) {
      return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, width: 1000, height: 800 } };
    }
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  // WhatsApp disina gidilmesin
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith(WA_URL) && !url.startsWith(START_URL) && !url.startsWith('blob:')) {
      e.preventDefault();
      if (/^https?:/i.test(url)) shell.openExternal(url);
    }
  });

  // Internet yoksa bos ekran yerine bilgi sayfasi + otomatik tekrar deneme
  win.webContents.on('did-fail-load', (e, code, desc, url, isMainFrame) => {
    if (!isMainFrame || code === -3) return;   // -3 = iptal (sorun degil)
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(OFFLINE_HTML)).catch(() => {});
  });

  // Render sureci cokerse otomatik yeniden yukle
  win.webContents.on('render-process-gone', () => {
    setTimeout(() => { if (!win.isDestroyed()) win.loadURL(START_URL).catch(() => {}); }, 1000);
  });

  // Sag tik menusu (Electron'da varsayilan yok): kopyala / yapistir / link
  win.webContents.on('context-menu', (e, p) => {
    const items = [];
    if (p.linkURL) items.push({ label: 'Linki kopyala', click: () => require('electron').clipboard.writeText(p.linkURL) });
    if (p.isEditable) {
      items.push({ role: 'cut', label: 'Kes' }, { role: 'copy', label: 'Kopyala' }, { role: 'paste', label: 'Yapistir' }, { type: 'separator' }, { role: 'selectAll', label: 'Tumunu sec' });
    } else if (p.selectionText) {
      items.push({ role: 'copy', label: 'Kopyala' });
    }
    if (items.length) Menu.buildFromTemplate(items).popup({ window: win });
  });

  mainWin = win;
  applyAppDetails();
  if (!tray) createTray();
  updateShortcutIcon();
  win.loadURL(START_URL).catch(() => {});
  return win;
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const w = BrowserWindow.getAllWindows()[0];
    if (w) { if (w.isMinimized()) w.restore(); w.show(); w.focus(); }
  });
  app.whenReady().then(startup);
  app.on('window-all-closed', () => app.quit());
}
