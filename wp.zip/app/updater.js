// Tam surum guncellemesi: GitHub'daki wp.zip'i acar, dogrular, app/ klasorunun uzerine kurar.
// Harici kutuphane gerektirmez (zip'i kendisi okur). Hata olursa eski dosyalari geri yukler.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const vm = require('vm');

const readNum = (s) => { const n = parseInt(String(s).trim(), 10); return Number.isFinite(n) ? n : 0; };

// ZIP -> [{ name, data }]
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Zip dosyasi bozuk (son kayit bulunamadi)');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Zip dosyasi bozuk (dizin)');
    const method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
    const lho = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nlen);
    p += 46 + nlen + elen + clen;
    if (name.endsWith('/') || name.endsWith('\\')) continue;
    if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error('Zip dosyasi bozuk (yerel baslik)');
    const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('Desteklenmeyen zip sikistirmasi: ' + method);
    if (data.length !== usize) throw new Error('Zip dosyasi bozuk (boyut): ' + name);
    out.push({ name, data });
  }
  return out;
}

// Zip'in icinde app/ klasorunu bulur (ustte ekstra klasor olsa da olur) -> [{ rel, data }]
function pickAppFiles(entries) {
  const norm = entries.map((e) => ({ name: e.name.replace(/\\/g, '/'), data: e.data }));
  const m = norm.find((e) => /(^|\/)app\/main\.js$/.test(e.name));
  if (!m) throw new Error('Zip icinde app/main.js yok');
  const prefix = m.name.slice(0, m.name.length - 'main.js'.length);   // "...app/"
  const files = [];
  for (const e of norm) {
    if (!e.name.startsWith(prefix)) continue;
    const rel = e.name.slice(prefix.length);
    if (!rel) continue;
    const parts = rel.split('/');
    if (rel.startsWith('/') || /^[a-zA-Z]:/.test(rel) || parts.some((s) => s === '..' || s === '.' || s === '')) {
      throw new Error('Gecersiz dosya yolu: ' + rel);
    }
    files.push({ rel, data: e.data });
  }
  return files;
}

// Kurmadan once kontrol: gerekli dosyalar var mi, .js dosyalarinda sozdizimi hatasi var mi, surum numarasi beklenen mi
function validate(files, expectedVersion) {
  const names = new Set(files.map((f) => f.rel));
  for (const need of ['main.js', 'preload.js', 'content.js', 'updater.js', 'appversion.txt']) {
    if (!names.has(need)) throw new Error('Zip icinde eksik dosya: app/' + need);
  }
  for (const f of files) {
    if (/\.js$/i.test(f.rel) && !/^lib\//.test(f.rel)) {
      try { new vm.Script(f.data.toString('utf8'), { filename: f.rel }); }
      catch (e) { throw new Error(f.rel + ' dosyasinda hata var: ' + e.message); }
    }
  }
  if (expectedVersion != null) {
    const zv = readNum(files.find((f) => f.rel === 'appversion.txt').data.toString('utf8'));
    if (zv < expectedVersion) {
      throw new Error('Sunucudaki wp.zip henuz guncel degil (icindeki surum ' + zv + ', beklenen ' + expectedVersion + '). Biraz sonra tekrar dene.');
    }
  }
}

// Dosyalari appDir'in uzerine yazar. Once appDir_yedek'e yedek alir, hata olursa geri yukler.
// appversion.txt en son yazilir: yarida kalirsa "guncellendi" sayilmaz.
function installFiles(files, appDir) {
  const backup = appDir + '_yedek';
  fs.rmSync(backup, { recursive: true, force: true });
  fs.cpSync(appDir, backup, { recursive: true });
  const ordered = files.filter((f) => f.rel !== 'appversion.txt').concat(files.filter((f) => f.rel === 'appversion.txt'));
  try {
    for (const f of ordered) {
      const dest = path.join(appDir, f.rel);
      if (path.relative(appDir, dest).startsWith('..')) throw new Error('Yol klasor disina tasiyor: ' + f.rel);
      try { if (fs.readFileSync(dest).equals(f.data)) continue; } catch (e) {}    // ayniysa dokunma
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, f.data);
    }
  } catch (e) {
    try { fs.cpSync(backup, appDir, { recursive: true, force: true }); } catch (e2) {}
    throw e;
  }
}

module.exports = { readZip, pickAppFiles, validate, installFiles, readNum };
