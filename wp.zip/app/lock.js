// Uygulama kilidi: sifre saklama/dogrulama ve yanlis deneme bekletmesi (Electron'dan bagimsiz, test edilebilir)
const crypto = require('crypto');

const MIN_LEN = 4;

// Sifre asla duz yazilmaz: rastgele tuz + scrypt ozeti saklanir
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(pw), salt, 32).toString('hex');
  return { salt, hash };
}

function verifyPassword(pw, rec) {
  try {
    if (!rec || !rec.salt || !rec.hash) return false;
    const h = crypto.scryptSync(String(pw == null ? '' : pw), rec.salt, 32);
    const exp = Buffer.from(rec.hash, 'hex');
    return h.length === exp.length && crypto.timingSafeEqual(h, exp);
  } catch (e) { return false; }
}

// 5 yanlis denemeden sonra bekletir: 10, 20, 40 ... en fazla 300 sn
class Throttle {
  constructor() { this.fails = 0; this.until = 0; }
  wait(now = Date.now()) { return Math.max(0, Math.ceil((this.until - now) / 1000)); }
  fail(now = Date.now()) {
    this.fails++;
    if (this.fails >= 5) this.until = now + Math.min(300, 10 * Math.pow(2, this.fails - 5)) * 1000;
  }
  ok() { this.fails = 0; this.until = 0; }
}

module.exports = { MIN_LEN, hashPassword, verifyPassword, Throttle };
