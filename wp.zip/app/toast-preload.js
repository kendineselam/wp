// Bildirim penceresi (toast.html) <-> ana surec koprusu
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('toast', {
  onInit: (cb) => ipcRenderer.on('toast:init', (e, d) => cb(d)),
  onOut: (cb) => ipcRenderer.on('toast:out', () => cb()),
  click: () => ipcRenderer.send('toast:click'),
  close: () => ipcRenderer.send('toast:close'),
  hover: (on) => ipcRenderer.send('toast:hover', !!on)
});
