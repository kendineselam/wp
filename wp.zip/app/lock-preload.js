// Kilit ekrani (lockui.html) <-> ana surec koprusu
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('lockApi', {
  unlock: (pw) => ipcRenderer.invoke('lock:unlock', pw),
  set: (oldPw, newPw) => ipcRenderer.invoke('lock:set', { oldPw, newPw }),
  remove: (pw) => ipcRenderer.invoke('lock:remove', pw),
  reset: () => ipcRenderer.invoke('lock:reset'),
  close: () => ipcRenderer.send('lock:close')
});
