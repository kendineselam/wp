// PDF.js + PDF Roket kodunu sayfanin ana dunyasinda calistirir
// (eklentideki "world: MAIN" ile ayni mantik). executeJavaScript sayfa CSP'sine takilmaz.
// content.js: main.js verir (GitHub'dan guncellenmis varsa o, yoksa zip'taki).
const { webFrame, ipcRenderer } = require('electron');
const fs = require('fs');
const path = require('path');

try {
  const read = (p) => fs.readFileSync(path.join(__dirname, p), 'utf8');
  const content = ipcRenderer.sendSync('pr:code') || read('content.js');
  const code = [read('lib/pdf.min.js'), read('lib/pdf.worker.min.js'), content].join('\n;\n');
  webFrame.executeJavaScript(code).catch((e) => {
    console.error('[PDF-ROKET] yukleme hatasi:', e);
    ipcRenderer.send('pr:bad');
  });
} catch (e) {
  console.error('[PDF-ROKET] preload hatasi:', e);
}
