// PDF.js + PDF Roket kodunu sayfanin ana dunyasinda calistirir
// (eklentideki "world: MAIN" ile ayni mantik). executeJavaScript sayfa CSP'sine takilmaz.
// content.js: main.js verir (GitHub'dan guncellenmis varsa o, yoksa zip'taki).
const { webFrame, ipcRenderer, contextBridge } = require('electron');
const fs = require('fs');
const path = require('path');

// ---------------- Bildirim koprusu ----------------
// WhatsApp Web'in "new Notification(...)" cagrilarini yakalayip uygulamanin kendi bildirim sistemine yollar.
const NOTIF_SHIM = `(function () {
  if (window.__prNotifPatched || !window.__prNotify) return;
  window.__prNotifPatched = true;
  var api = window.__prNotify;
  var live = new Map();
  var seq = 0;
  function toDataUrl(src) {
    return new Promise(function (resolve) {
      if (!src) return resolve('');
      src = String(src);
      if (/^data:image\\//.test(src)) return resolve(src);
      if (/^blob:/.test(src)) {
        fetch(src).then(function (r) { return r.blob(); }).then(function (b) {
          var fr = new FileReader();
          fr.onload = function () { resolve(String(fr.result)); };
          fr.onerror = function () { resolve(''); };
          fr.readAsDataURL(b);
        }).catch(function () { resolve(''); });
      } else if (/^https:\\/\\//.test(src)) resolve(src);
      else resolve('');
    });
  }
  class PRNotification extends EventTarget {
    constructor(title, options) {
      super();
      var o = options || {};
      this.title = String(title == null ? '' : title);
      this.body = o.body == null ? '' : String(o.body);
      this.icon = o.icon || ''; this.tag = o.tag || ''; this.data = o.data;
      this.silent = !!o.silent; this.lang = o.lang || ''; this.dir = o.dir || 'auto';
      this.image = o.image || ''; this.badge = o.badge || '';
      this.requireInteraction = !!o.requireInteraction; this.renotify = !!o.renotify;
      this.timestamp = Date.now();
      this.onclick = null; this.onclose = null; this.onshow = null; this.onerror = null;
      this._id = ++seq; this._closed = false;
      live.set(this._id, this);
      if (live.size > 200) live.delete(live.keys().next().value);
      var self = this;
      toDataUrl(this.icon).then(function (icon) {
        if (self._closed) return;
        api.show({ id: self._id, title: self.title, body: self.body, tag: String(self.tag), icon: icon });
        setTimeout(function () { self._emit('show'); }, 0);
      });
    }
    _emit(type) {
      var ev = new Event(type);
      try { var h = this['on' + type]; if (typeof h === 'function') h.call(this, ev); } catch (e) {}
      try { this.dispatchEvent(ev); } catch (e) {}
    }
    close() { this._closed = true; api.close(this._id); }
    static get permission() { return 'granted'; }
    static requestPermission(cb) {
      if (typeof cb === 'function') { try { cb('granted'); } catch (e) {} }
      return Promise.resolve('granted');
    }
    static get maxActions() { return 0; }
  }
  api.onEvent(function (id, type) {
    var n = live.get(id);
    if (!n) return;
    live.delete(id);
    n._closed = true;
    if (type === 'click') n._emit('click');
    n._emit('close');
  });
  try { Object.defineProperty(window, 'Notification', { value: PRNotification, writable: true, configurable: true }); }
  catch (e) { window.Notification = PRNotification; }
  try {
    if (window.ServiceWorkerRegistration) {
      ServiceWorkerRegistration.prototype.showNotification = function (t, o) { new PRNotification(t, o); return Promise.resolve(); };
    }
  } catch (e) {}
})();`;

try {
  contextBridge.exposeInMainWorld('__prNotify', {
    show: (d) => ipcRenderer.send('pr:notify', d),
    close: (id) => ipcRenderer.send('pr:notify-close', id),
    onEvent: (cb) => { ipcRenderer.on('pr:notif-event', (e, id, type) => { try { cb(id, type); } catch (err) {} }); }
  });
  webFrame.executeJavaScript(NOTIF_SHIM).catch((e) => console.error('[PDF-ROKET] bildirim kopru hatasi:', e));
} catch (e) {
  console.error('[PDF-ROKET] bildirim kopru kurulamadi:', e);
}

// ---------------- PDF Roket ----------------
try {
  const read = (p) => fs.readFileSync(path.join(__dirname, p), 'utf8');
  const content = ipcRenderer.sendSync('pr:code') || read('content.js');
  const code = [read('lib/pdf.min.js'), read('lib/pdf.worker.min.js'), content].join('\n;\n');
  webFrame.executeJavaScript(code).catch((e) => {
    console.error('[PDF-ROKET] yukleme hatasi:', e);
    ipcRenderer.send('pr:bad');
  });
} catch (e) {
  console.error('[PDF-ROKET] preload hatasi:', e);
}
