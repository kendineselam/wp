// "Yeni Sekmede Ac" ile acilan ayri PDF penceresi: ayni PDF.js + content.js goruntuleyicisini kullanir.
const { webFrame, ipcRenderer, contextBridge } = require('electron');
const fs = require('fs');
const path = require('path');

const id = new URLSearchParams(location.search).get('id');
try {
  contextBridge.exposeInMainWorld('__prPdf', {
    getData: () => ipcRenderer.invoke('pr:pdf-get', id)
  });
  const read = (p) => fs.readFileSync(path.join(__dirname, p), 'utf8');
  const content = ipcRenderer.sendSync('pr:code') || read('content.js');
  const code = ['window.__prStandalone = true;', read('lib/pdf.min.js'), read('lib/pdf.worker.min.js'), content].join('\n;\n');
  webFrame.executeJavaScript(code).catch((e) => console.error('[PDF-ROKET] pdf penceresi yukleme hatasi:', e));
} catch (e) {
  console.error('[PDF-ROKET] pdf penceresi preload hatasi:', e);
}
