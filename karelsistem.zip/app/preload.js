const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('__karel', {
  callAdded: (id, number) => ipcRenderer.send('call-added', String(id), String(number)),
  callRemoved: (id) => ipcRenderer.send('call-removed', String(id)),
  loginCaptured: (u, p) => ipcRenderer.send('login-captured', String(u), String(p))
});
