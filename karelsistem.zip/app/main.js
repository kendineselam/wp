const { app, BrowserWindow, Menu, Tray, Notification, nativeImage, ipcMain, screen, session, shell, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const vm = require('vm');
const { execFile } = require('child_process');

// ================= AYARLAR =================
const SITE_URL = 'https://santral.karel.cloud/user/internalstatus';
const SITE_HOST = 'santral.karel.cloud';
const REPO_RAW = 'https://raw.githubusercontent.com/kendineselam/karel/main/';
const MANIFEST = 'manifest.json';      // script listesi + script surumu
const ZIP_NAME = 'karelsistem.zip';    // programin kendisi (tam guncelleme)
const VER_FILE = 'appversion.txt';     // program surumu
// ===========================================

// Uygulama adi (Gorev Yoneticisi, bildirimler, pencere). Ayar/script klasoru ESKI yerinde kalir.
const APP_NAME = 'KAREL SANTRAL';
const OLD_APP_NAME = 'karel-santral-masaustu';
app.setPath('userData', path.join(app.getPath('appData'), OLD_APP_NAME));
app.setName(APP_NAME);
app.setAppUserModelId('com.karel.santral');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
// Pencere kucukken / arkadayken / tepsideyken de cagri yakalamaya devam etsin
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
if (!app.requestSingleInstanceLock()) app.quit();

const APP_DIR = __dirname;
const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const scriptsDir = () => path.join(app.getPath('userData'), 'scripts');

let splash = null;
let win = null;
let tray = null;
let quitting = false;
let current = null; // yuklu script manifesti

function log(m) {
  try {
    const f = path.join(ROOT, 'uygulama-log.txt');
    if (fs.existsSync(f) && fs.statSync(f).size > 100 * 1024) fs.rmSync(f, { force: true });
    fs.appendFileSync(f, new Date().toLocaleString('tr-TR') + ' ' + m + '\n');
  } catch (e) {}
}

// ================== KULLANICI AYARLARI ==================
const DEFAULTS = {
  showNotifications: true,  // bildirimler genel anahtar
  popup: true,              // ekran popup'i (her zaman ustte)
  toast: true,              // Windows bildirimi
  inPage: false,            // sitedeki sari popup
  bringToFront: false,      // cagri gelince pencereyi one getir
  position: 'top-right',
  duration: 20,             // sn, 0 = ben kapatana kadar
  startWithWindows: false,
  startMinimized: false,
  closeToTray: true,
  autoLogin: true           // giris bilgisini hatirla + otomatik giris
};
let settings = { ...DEFAULTS };
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
function loadSettings() {
  try { settings = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) }; } catch (e) {}
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (e) { log('Ayar kaydedilemedi: ' + e.message); }
}

const POSITIONS = [
  ['top-right', 'Sağ üst'], ['bottom-right', 'Sağ alt'], ['top-left', 'Sol üst'], ['bottom-left', 'Sol alt'],
  ['top-center', 'Üst orta'], ['bottom-center', 'Alt orta'], ['center', 'Ekranın ortası']
];
const DURATIONS = [[5, '5 saniye'], [10, '10 saniye'], [20, '20 saniye'], [30, '30 saniye'], [60, '60 saniye'], [0, 'Ben kapatana kadar']];

function applyLoginItem() {
  try { app.setLoginItemSettings({ openAtLogin: false, name: OLD_APP_NAME }); } catch (e) {} // eski adla kalan kaydi temizle
  try {
    app.setLoginItemSettings({
      openAtLogin: !!settings.startWithWindows,
      name: APP_NAME,
      path: process.execPath,
      args: [ROOT].concat(settings.startMinimized ? ['--hidden'] : [])
    });
  } catch (e) { log('Windows ile başlatma ayarlanamadı: ' + e.message); }
}

function setSetting(key, value) {
  settings[key] = value;
  saveSettings();
  if (key === 'startWithWindows' || key === 'startMinimized') applyLoginItem();
  if (key === 'inPage') applyInPage();
  buildMenu();
  if (key === 'position' || key === 'duration') previewNotification(); // ayar degisince ornek goster
}

// ================== YARDIMCILAR ==================
function localAppVersion() {
  try { return parseInt(fs.readFileSync(path.join(APP_DIR, VER_FILE), 'utf8').trim(), 10) || 0; } catch (e) { return 0; }
}
async function fetchBuf(url, ms = 15000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal, cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return Buffer.from(await r.arrayBuffer());
  } finally { clearTimeout(t); }
}
const fetchText = async (url, ms) => (await fetchBuf(url, ms)).toString('utf8');

function run(file, args) {
  return new Promise((res, rej) => execFile(file, args, { windowsHide: true }, (e) => (e ? rej(e) : res())));
}
async function extractZip(zip, dest) {
  const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
  try {
    if (!fs.existsSync(tar)) throw new Error('tar yok');
    await run(tar, ['-xf', zip, '-C', dest]);
  } catch (e) {
    await run('powershell.exe', ['-NoProfile', '-Command',
      `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dest}' -Force`]);
  }
}

// ================== GUNCELLEME KONTROLU DURUMU ==================
const CHECK_MS = 5000; // acilis ekranindaki guncelleme kontrolu suresi
let updateState = { appFail: false, scriptFail: false, failed: false, scriptsUpdated: false, reason: '' };
function reasonOf(msg) {
  msg = String(msg || '');
  const h = msg.match(/HTTP (\d+)/);
  if (h) return `GitHub'dan dosya alınamadı (HTTP ${h[1]})`;
  if (/manifest|JSON/i.test(msg)) return 'Script listesi (manifest.json) bozuk';
  return 'Sunucuya ulaşılamadı';
}
let ticker = null;
function stopTicker() { if (ticker) { clearInterval(ticker); ticker = null; } }
function startTicker(t0, ms) {
  stopTicker();
  if (!ms) return;
  ticker = setInterval(() => say(null, Math.min(95, ((Date.now() - t0) / ms) * 100)), 120);
}
function finalMessage() {
  const u = updateState;
  if (u.appFail && u.scriptFail) return (u.reason && u.reason !== 'Sunucuya ulaşılamadı' ? u.reason : 'İnternete ulaşılamadı') + ', mevcut sürümle devam ediliyor.';
  if (u.appFail || u.scriptFail) return `Güncelleme kontrol edilemedi (${u.reason}), mevcut sürümle devam ediliyor.`;
  if (u.failed) return 'Güncelleme tamamlanamadı, mevcut sürümle devam ediliyor.';
  if (u.scriptsUpdated) return 'Güncelleme tamamlandı, devam edelim!';
  return 'Harika! Her şey güncel, devam edelim.';
}
// Splash'ta guncelleme var/yok kontrolu. minMs: ekranin en az kac ms acik kalacagi. 'relaunch' donerse program yeniden basliyor.
async function runUpdateCheck(minMs) {
  const t0 = Date.now();
  updateState = { appFail: false, scriptFail: false, failed: false, scriptsUpdated: false, reason: '' };
  say('Güncellemeler kontrol ediliyor...', 0);
  startTicker(t0, minMs);
  if (await checkAppUpdate(say)) return 'relaunch';
  current = (await checkScripts(say)) || current;
  const visible = splash && !splash.isDestroyed();
  if (visible) await sleep(Math.max(0, minMs - 1700 - (Date.now() - t0))); // sonuc, sürenin son ~1.7 sn'sinde gorunsun
  say(finalMessage(), 100);
  if (visible) await sleep(Math.max(1200, minMs - (Date.now() - t0)));
  return 'ok';
}

// ================== 1) PROGRAMIN KENDISI (appversion.txt + karelsistem.zip) ==================
async function checkAppUpdate(say) {
  const local = localAppVersion();
  let remote;
  try {
    remote = parseInt((await fetchText(REPO_RAW + VER_FILE + '?t=' + Date.now(), 10000)).trim(), 10);
  } catch (e) { log('Program sürümü okunamadı: ' + e.message); updateState.appFail = true; updateState.reason = reasonOf(e.message); return false; }
  if (!Number.isInteger(remote) || remote <= local) return false;

  say('Yeni güncelleme bulundu!', 25);
  await sleep(1200);
  const work = path.join(os.tmpdir(), 'karel_update');
  try {
    fs.rmSync(work, { recursive: true, force: true });
    fs.mkdirSync(path.join(work, 'x'), { recursive: true });

    say('Program güncellemesi indiriliyor...', 35);
    const zipPath = path.join(work, 'update.zip');
    fs.writeFileSync(zipPath, await fetchBuf(REPO_RAW + ZIP_NAME + '?t=' + Date.now(), 180000));

    say('Dosyalar açılıyor...', 55);
    const ex = path.join(work, 'x');
    await extractZip(zipPath, ex);

    // kontrol: dosyalar tam mi, surum uyuyor mu, kodda sozdizimi hatasi var mi
    const nApp = path.join(ex, 'app');
    for (const f of ['main.js', 'splash.html', VER_FILE]) {
      if (!fs.existsSync(path.join(nApp, f))) throw new Error('zip eksik: app/' + f);
    }
    const zv = parseInt(fs.readFileSync(path.join(nApp, VER_FILE), 'utf8').trim(), 10);
    if (zv !== remote) throw new Error(`zip sürümü (${zv}) appversion.txt (${remote}) ile uyuşmuyor`);
    new vm.Script(fs.readFileSync(path.join(nApp, 'main.js'), 'utf8')); // sozdizimi kontrolu

    say('Kuruluyor...', 75);
    const backup = path.join(ROOT, 'app_yedek');
    fs.rmSync(backup, { recursive: true, force: true });
    fs.cpSync(APP_DIR, backup, { recursive: true });
    fs.cpSync(nApp, APP_DIR, { recursive: true, force: true });

    log(`Program güncellendi: v${local} -> v${remote}`);
    say('Program yeniden başlatılıyor...', 100);
    await sleep(900);
    fs.rmSync(work, { recursive: true, force: true });
    quitting = true;
    app.relaunch();
    app.exit(0);
    return true;
  } catch (e) {
    log('Program güncellemesi başarısız: ' + e.message);
    fs.rmSync(work, { recursive: true, force: true });
    updateState.failed = true;
    say('Program güncellemesi başarısız, mevcut sürümle devam ediliyor', 100);
    await sleep(1600);
    return false;
  }
}

// ================== 2) SCRIPTLER (manifest.json + .user.js dosyalari) ==================
function readLocalManifest() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(scriptsDir(), MANIFEST), 'utf8'));
    if (m.scripts.every((f) => fs.existsSync(path.join(scriptsDir(), f)))) return m;
  } catch (e) {}
  return null;
}

async function checkScripts(say) {
  const local = readLocalManifest();

  let remote;
  try {
    remote = JSON.parse(await fetchText(REPO_RAW + MANIFEST + '?t=' + Date.now(), 10000));
    if (!remote.version || !Array.isArray(remote.scripts)) throw new Error('manifest bozuk');
  } catch (e) {
    log('Manifest okunamadı: ' + e.message);
    updateState.scriptFail = true; updateState.reason = reasonOf(e.message);
    return local;
  }

  if (local && String(local.version) === String(remote.version)) return local;

  say('Yeni güncelleme bulundu!', 30);
  await sleep(1200);

  const tmp = scriptsDir() + '_new';
  try {
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    const n = remote.scripts.length;
    for (let i = 0; i < n; i++) {
      const f = remote.scripts[i];
      if (f.includes('..')) throw new Error('geçersiz dosya adı');
      say(`İndiriliyor (${i + 1}/${n}): ${f}`, 30 + Math.round((60 * i) / n));
      const code = await fetchText(REPO_RAW + encodeURI(f) + '?t=' + Date.now(), 20000);
      if (code.trim().length < 10 || /^\s*<!doctype html/i.test(code)) throw new Error(f + ' geçersiz');
      const dest = path.join(tmp, f);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, code);
    }
    fs.writeFileSync(path.join(tmp, MANIFEST), JSON.stringify(remote, null, 2));
    fs.rmSync(scriptsDir(), { recursive: true, force: true });
    fs.renameSync(tmp, scriptsDir());
    log('Scriptler güncellendi: v' + remote.version);
    updateState.scriptsUpdated = true;
    return remote;
  } catch (e) {
    log('Script güncellemesi başarısız: ' + e.message);
    updateState.failed = true; updateState.reason = reasonOf(e.message);
    fs.rmSync(tmp, { recursive: true, force: true });
    say('Script güncellemesi başarısız, ' + (local ? 'kayıtlı sürüm kullanılıyor' : 'script bulunamadı'), 100);
    await sleep(1600);
    return local;
  }
}

// ---------- @match isleme ----------
function globToRegex(g) {
  if (g === '*' || g === '<all_urls>') return /^https?:\/\/.*/;
  const esc = g.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
  return new RegExp('^' + esc + '$');
}
function parseHeader(code) {
  const h = (code.match(/==UserScript==([\s\S]*?)==\/UserScript==/) || [])[1] || '';
  const grab = (tag) => [...h.matchAll(new RegExp('@' + tag + '\\s+(\\S+)', 'g'))].map((m) => m[1]);
  return { match: [...grab('match'), ...grab('include')], exclude: grab('exclude') };
}
function shouldRun(meta, url) {
  if (meta.exclude.some((g) => globToRegex(g).test(url))) return false;
  if (meta.match.length === 0) return true;
  return meta.match.some((g) => globToRegex(g).test(url));
}
async function injectScripts(wc) {
  if (!current) return;
  const url = wc.getURL();
  for (const f of current.scripts) {
    try {
      const code = fs.readFileSync(path.join(scriptsDir(), f), 'utf8');
      if (!shouldRun(parseHeader(code), url)) continue;
      const key = JSON.stringify(f);
      await wc.executeJavaScript(
        `(function(){window.__ks=window.__ks||{};if(window.__ks[${key}])return;window.__ks[${key}]=1;\n${code}\n})();`
      );
      log('Script çalıştı: ' + f);
    } catch (e) { log('Script hatası (' + f + '): ' + e.message); }
  }
}

// ================== GIRIS BILGISINI HATIRLA (otomatik giris) ==================
// Sifre Windows hesabina bagli sekilde (DPAPI / safeStorage) sifrelenerek userData\login.dat icinde saklanir.
const credFile = () => path.join(app.getPath('userData'), 'login.dat');
let savedUser = null;    // menude gostermek icin (sifre degil)
let loginPending = null; // { u, p, auto } giris denemesi sonucu bekleniyor
let autoTries = 0;       // bu calismada otomatik giris deneme sayisi (dongu korumasi)

function loadCreds() {
  try {
    if (!safeStorage.isEncryptionAvailable() || !fs.existsSync(credFile())) return null;
    const o = JSON.parse(safeStorage.decryptString(fs.readFileSync(credFile())));
    return o && o.p ? o : null;
  } catch (e) { log('Kayıtlı giriş okunamadı: ' + e.message); return null; }
}
function saveCreds(u, p) {
  try {
    if (!safeStorage.isEncryptionAvailable()) { log('Giriş bilgisi kaydedilemedi: şifreleme kullanılamıyor'); return; }
    const old = loadCreds();
    if (old && old.u === u && old.p === p) return;
    fs.mkdirSync(path.dirname(credFile()), { recursive: true });
    fs.writeFileSync(credFile(), safeStorage.encryptString(JSON.stringify({ u, p })));
    savedUser = u || '(kullanıcı adı yok)';
    log('Giriş bilgisi kaydedildi');
    buildMenu();
  } catch (e) { log('Giriş bilgisi kaydedilemedi: ' + e.message); }
}
function deleteCreds() {
  try { fs.rmSync(credFile(), { force: true }); } catch (e) {}
  savedUser = null; loginPending = null; autoTries = 99; // bu calismada tekrar otomatik doldurma
  log('Kayıtlı giriş bilgisi silindi');
  buildMenu();
}

// Sayfanin icinde calisir (toString ile enjekte edilir): giris formunu bulur, gonderilen bilgiyi yakalar, doldurur.
function loginMain() {
  if (window.__karelLoginOn) return;
  window.__karelLoginOn = true;
  function visible(el) { return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length); }
  function pwField() {
    var l = document.querySelectorAll('input[type=password]');
    for (var i = 0; i < l.length; i++) if (visible(l[i])) return l[i];
    return null;
  }
  function userField(pw) {
    var scope = pw.form || document;
    var ok = ['text', 'email', 'tel', 'number', ''];
    var list = [].slice.call(scope.querySelectorAll('input')).filter(function (i) {
      return ok.indexOf((i.getAttribute('type') || '').toLowerCase()) !== -1 && visible(i);
    });
    var before = list.filter(function (i) { return i.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING; });
    return before[before.length - 1] || list[0] || null;
  }
  function setVal(el, v) {
    if (!el) return;
    var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    el.focus();
    d.set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function capture() {
    if (window.__karelFilling) return;
    var pw = pwField();
    if (!pw || !pw.value) return;
    var u = userField(pw);
    try { window.__karel.loginCaptured(u ? u.value : '', pw.value); } catch (e) {}
  }
  document.addEventListener('submit', capture, true);
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest && e.target.closest('button, input[type=submit], [type=submit]');
    if (b && pwField()) capture();
  }, true);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && e.target && e.target.tagName === 'INPUT' && pwField()) capture();
  }, true);

  window.__karelHasPw = function () { return !!pwField(); };
  window.__karelFill = function (u, p) {
    var pw = pwField();
    if (!pw) return false;
    window.__karelFilling = true;
    setVal(userField(pw), u);
    setVal(pw, p);
    setTimeout(function () {
      var form = pw.form;
      var btn = (form && (form.querySelector('button[type=submit],input[type=submit]') ||
                          form.querySelector('button:not([type=button]):not([type=reset])'))) ||
                document.querySelector('button[type=submit],input[type=submit]');
      if (btn) btn.click();
      else if (form && form.requestSubmit) form.requestSubmit();
      else pw.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      setTimeout(function () { window.__karelFilling = false; }, 1500);
    }, 400);
    return true;
  };
}

const onSiteUrl = (u) => { try { return new URL(u).hostname === SITE_HOST; } catch (e) { return false; } };

async function injectLogin(wc) {
  try {
    if (!onSiteUrl(wc.getURL())) return;
    await wc.executeJavaScript('(' + loginMain.toString() + ')();true');
    await handleLoginPage(wc, false);
    setTimeout(() => handleLoginPage(wc, true), 1500); // gec cizilen formlar icin
  } catch (e) { log('Giriş köprüsü hatası: ' + e.message); }
}

// soft=true: sayfa yeniden yuklenmeden yapilan kontrol (zamanlayici / sayfa ici gezinme)
async function handleLoginPage(wc, soft) {
  if (!wc || wc.isDestroyed() || !settings.autoLogin || !onSiteUrl(wc.getURL())) return;
  let hasPw;
  try { hasPw = await wc.executeJavaScript('!!(window.__karelHasPw && window.__karelHasPw())'); } catch (e) { return; }

  if (!hasPw) { // giris formu yok = giris yapilmis
    if (loginPending) {
      if (!loginPending.auto) saveCreds(loginPending.u, loginPending.p);
      loginPending = null;
    }
    autoTries = 0;
    return;
  }
  // giris formu var
  if (!soft && loginPending) { // sayfa yeniden yuklendi ve hala giris ekrani = giris basarisiz
    log(loginPending.auto ? 'Otomatik giriş başarısız (kayıtlı bilgi yanlış olabilir)' : 'Giriş başarısız, bilgi kaydedilmedi');
    if (loginPending.auto) autoTries = 99;
    loginPending = null;
    return;
  }
  if (loginPending) return;
  const c = loadCreds();
  if (!c || autoTries >= 2) return;
  autoTries++;
  loginPending = { u: c.u, p: c.p, auto: true };
  log('Otomatik giriş deneniyor');
  wc.executeJavaScript(`window.__karelFill(${JSON.stringify(c.u)},${JSON.stringify(c.p)})`).catch(() => {});
}

ipcMain.on('login-captured', (e, u, p) => {
  if (!fromSite(e) || !p || !settings.autoLogin) return;
  loginPending = { u: String(u || ''), p: String(p), auto: false };
  setTimeout(() => { if (win && !win.isDestroyed()) handleLoginPage(win.webContents, true); }, 4000); // sayfa yenilenmeyen (AJAX) girisler icin
});

// ================== SAYFAYA KOPRU ==================
// Bu fonksiyon sayfanin icinde calisir (toString ile enjekte edilir).
// - Sayfanin kendi Notification'ini susturur (Windows bildirimini artik uygulama yonetir)
// - Scriptin actigi sari popup'lari (data-call-id) izler ve uygulamaya haber verir
function bridgeMain() {
  if (window.__karelBridgeOn) return;
  window.__karelBridgeOn = true;

  try {
    var Fake = function () {};
    Fake.permission = 'granted';
    Fake.requestPermission = function (cb) { if (cb) cb('granted'); return Promise.resolve('granted'); };
    Fake.prototype.close = function () {};
    window.Notification = Fake;
  } catch (e) {}

  var st = document.createElement('style');
  st.id = 'karel-hide-inpage';
  (document.head || document.documentElement).appendChild(st);
  window.__karelHideInPage = function (hide) {
    st.textContent = hide ? '[data-call-id]{display:none!important}' : '';
  };

  function numberOf(n) {
    var s = n.querySelector('span');
    var t = ((s ? s.textContent : n.textContent) || '').trim();
    var m = t.match(/Arayan Numara:\s*(.+)$/);
    return (m ? m[1] : t).trim();
  }
  function each(list, fn) {
    list.forEach(function (n) {
      if (n.nodeType !== 1) return;
      if (n.hasAttribute('data-call-id')) fn(n);
      n.querySelectorAll('[data-call-id]').forEach(fn);
    });
  }
  new MutationObserver(function (muts) {
    muts.forEach(function (m) {
      each(m.addedNodes, function (n) {
        try { window.__karel.callAdded(n.getAttribute('data-call-id'), numberOf(n)); } catch (e) {}
      });
      each(m.removedNodes, function (n) {
        try { window.__karel.callRemoved(n.getAttribute('data-call-id')); } catch (e) {}
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
}

function injectBridge(wc) {
  return wc.executeJavaScript(
    '(' + bridgeMain.toString() + ')();window.__karelHideInPage(' + (!settings.inPage) + ');'
  ).catch((e) => log('Köprü hatası: ' + e.message));
}
function applyInPage() {
  if (!win || win.isDestroyed()) return;
  win.webContents.executeJavaScript(
    'window.__karelHideInPage&&window.__karelHideInPage(' + (!settings.inPage) + ')'
  ).catch(() => {});
}
function closeInPage(id) {
  if (!win || win.isDestroyed()) return;
  win.webContents.executeJavaScript(
    '(function(){var n=document.querySelector("[data-call-id=" + JSON.stringify(' + JSON.stringify(id) + ') + "]");' +
    'var b=n&&n.querySelector("button");if(b)b.click();})()'
  ).catch(() => {});
}

// ================== EKRAN POPUP'LARI ==================
const POP_W = 380, POP_H = 96, POP_GAP = 10, POP_MARGIN = 16, MAX_POPUPS = 4;
const popups = new Map(); // id -> { win, timer }

function popupBounds(index, count, wa) {
  const pos = settings.position;
  let x;
  if (pos.endsWith('right')) x = wa.x + wa.width - POP_W - POP_MARGIN;
  else if (pos.endsWith('left')) x = wa.x + POP_MARGIN;
  else x = Math.round(wa.x + (wa.width - POP_W) / 2);
  let y;
  if (pos.startsWith('top')) y = wa.y + POP_MARGIN + index * (POP_H + POP_GAP);
  else if (pos.startsWith('bottom')) y = wa.y + wa.height - POP_H - POP_MARGIN - index * (POP_H + POP_GAP);
  else y = Math.round(wa.y + (wa.height - POP_H) / 2 + (index - (count - 1) / 2) * (POP_H + POP_GAP));
  return { x, y, width: POP_W, height: POP_H };
}

function layoutPopups() {
  const ref = win && !win.isDestroyed() ? win.getBounds() : null;
  const display = ref ? screen.getDisplayMatching(ref) : screen.getPrimaryDisplay();
  const list = [...popups.values()].filter((p) => !p.win.isDestroyed());
  list.forEach((p, i) => p.win.setBounds(popupBounds(i, list.length, display.workArea)));
}

function dismiss(id, fromUser) {
  const p = popups.get(id);
  if (!p) return;
  clearTimeout(p.timer);
  popups.delete(id);
  if (!p.win.isDestroyed()) p.win.destroy();
  layoutPopups();
  if (fromUser) closeInPage(id); // kullanici kapattiysa sitedeki popup da kapansin (cagri sesi de durur)
}

function createPopup(id, number) {
  while (popups.size >= MAX_POPUPS) dismiss(popups.keys().next().value, false);
  const w = new BrowserWindow({
    width: POP_W, height: POP_H, frame: false, transparent: true, resizable: false, movable: false,
    minimizable: false, maximizable: false, skipTaskbar: true, alwaysOnTop: true, focusable: false,
    show: false, hasShadow: false,
    webPreferences: { preload: path.join(APP_DIR, 'popup-preload.js'), contextIsolation: true, backgroundThrottling: false }
  });
  w.setAlwaysOnTop(true, 'screen-saver');
  const entry = { win: w, timer: null };
  popups.set(id, entry);
  if (settings.duration > 0) entry.timer = setTimeout(() => dismiss(id, false), settings.duration * 1000);
  w.on('closed', () => { clearTimeout(entry.timer); if (popups.get(id) === entry) popups.delete(id); });
  w.loadFile(path.join(APP_DIR, 'popup.html'));
  w.webContents.once('did-finish-load', () => {
    if (w.isDestroyed()) return;
    w.webContents.send('popup-data', {
      number,
      time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      duration: settings.duration
    });
    layoutPopups();
    w.showInactive();
  });
}

function showToast(number) {
  try {
    if (!Notification.isSupported()) return;
    const n = new Notification({ title: 'Gelen çağrı', body: number, icon: iconPath(), silent: true });
    n.on('click', showMain);
    n.show();
  } catch (e) { log('Windows bildirimi gösterilemedi: ' + e.message); }
}

function showCall(id, number, opts = {}) {
  if (!opts.force && !settings.showNotifications) return;
  if (popups.has(id)) return;
  if (settings.popup) createPopup(id, number);
  if (settings.toast && !opts.noToast) showToast(number);
  if (settings.bringToFront && !opts.test) showMain();
}

function previewNotification() { // ayar degisince: sadece ekran popup'i, ornek
  if (!settings.popup) return;
  showCall('test-' + Date.now(), '0 (5xx) 000 00 00  — deneme', { force: true, test: true, noToast: true });
}
function sendTest() {
  showCall('test-' + Date.now(), '0 (5xx) 000 00 00  — deneme', { force: true, test: true });
}

// ----- sayfadan gelen olaylar -----
function fromSite(e) {
  try { return new URL(e.senderFrame.url).hostname === SITE_HOST; } catch (err) { return false; }
}
ipcMain.on('call-added', (e, id, number) => { if (fromSite(e) && id) showCall(id, number || '?'); });
ipcMain.on('call-removed', (e, id) => {
  if (!fromSite(e)) return;
  const p = popups.get(id);
  if (p && !p.win.isDestroyed()) p.win.webContents.send('popup-ended'); // cagri bitti, popup suresi dolana kadar kalir
});
// ----- popup'tan gelen olaylar -----
function idOfSender(wc) {
  for (const [id, p] of popups) if (!p.win.isDestroyed() && p.win.webContents.id === wc.id) return id;
  return null;
}
ipcMain.on('popup-close', (e) => { const id = idOfSender(e.sender); if (id) dismiss(id, true); });
ipcMain.on('popup-open', (e) => { const id = idOfSender(e.sender); showMain(); if (id) dismiss(id, false); });

// ================== PENCERELER ==================
const iconPath = () => { const p = path.join(APP_DIR, 'icon.ico'); return fs.existsSync(p) ? p : undefined; };

function showMain() {
  if (!win || win.isDestroyed()) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function closeSplash() { if (splash && !splash.isDestroyed()) splash.close(); }

function createSplash() {
  splash = new BrowserWindow({
    width: 460, height: 320, frame: false, resizable: false, center: true, alwaysOnTop: true,
    show: false, backgroundColor: '#14171c', icon: iconPath(), skipTaskbar: false, title: APP_NAME,
    webPreferences: { contextIsolation: true }
  });
  splash.loadFile(path.join(APP_DIR, 'splash.html'));
  return new Promise((res) => splash.webContents.once('did-finish-load', () => { splash.show(); res(); }));
}
function say(text, pct) {
  if (text !== null) stopTicker(); // gercek bir mesaj gelince bekleme cubugu animasyonu durur
  if (splash && !splash.isDestroyed()) {
    splash.webContents.executeJavaScript(`setStatus(${JSON.stringify(text)},${pct})`).catch(() => {});
  }
}
const titleOf = () => APP_NAME;

function createMain(hidden) {
  win = new BrowserWindow({
    width: 1280, height: 800, show: !hidden, title: titleOf(), icon: iconPath(),
    webPreferences: {
      preload: path.join(APP_DIR, 'preload.js'),
      contextIsolation: true,
      backgroundThrottling: false // arka planda da çağrı yakalasın
    }
  });
  win.on('page-title-updated', (e) => e.preventDefault());
  win.webContents.on('did-finish-load', async () => {
    await injectBridge(win.webContents);
    await injectScripts(win.webContents);
    await injectLogin(win.webContents);
  });
  win.webContents.on('did-navigate-in-page', () => handleLoginPage(win.webContents, true));
  win.webContents.once('did-finish-load', closeSplash);
  win.webContents.once('did-fail-load', closeSplash);
  setTimeout(closeSplash, 10000); // site acilmasa bile acilis ekrani takilmasin
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith('https://' + SITE_HOST)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
  win.on('close', (e) => {
    if (!quitting && settings.closeToTray) { e.preventDefault(); win.hide(); }
  });
  win.on('closed', () => { [...popups.keys()].forEach((id) => dismiss(id, false)); app.quit(); });
  win.loadURL(SITE_URL);
}

function createTray() {
  const ic = iconPath();
  if (!ic) return;
  tray = new Tray(nativeImage.createFromPath(ic));
  tray.setToolTip(APP_NAME);
  tray.on('click', showMain);
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Göster', click: showMain },
    { label: 'Deneme bildirimi gönder', click: sendTest },
    { type: 'separator' },
    { label: 'Çıkış', click: () => { quitting = true; app.quit(); } }
  ]));
}

function buildMenu() {
  const chk = (label, key) => ({
    label, type: 'checkbox', checked: !!settings[key], click: (mi) => setSetting(key, mi.checked)
  });
  const radios = (items, key) => items.map(([v, l]) => ({
    label: l, type: 'radio', checked: settings[key] === v, click: () => setSetting(key, v)
  }));
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: APP_NAME,
      submenu: [
        { label: 'Yenile', accelerator: 'F5', click: () => win && win.reload() },
        { label: 'Geliştirici araçları', accelerator: 'F12', click: () => win && win.webContents.openDevTools({ mode: 'detach' }) },
        { type: 'separator' },
        { label: 'Çıkış', click: () => { quitting = true; app.quit(); } }
      ]
    },
    {
      label: 'Bildirimler',
      submenu: [
        chk('Bildirimleri göster', 'showNotifications'),
        { type: 'separator' },
        chk('Ekran popup\'ı (her zaman üstte)', 'popup'),
        chk('Windows bildirimi', 'toast'),
        chk('Sitedeki sarı popup\'ı da göster', 'inPage'),
        chk('Çağrı gelince pencereyi öne getir', 'bringToFront'),
        { type: 'separator' },
        { label: 'Konum', submenu: radios(POSITIONS, 'position') },
        { label: 'Ekranda kalma süresi', submenu: radios(DURATIONS, 'duration') },
        { type: 'separator' },
        { label: 'Deneme bildirimi gönder', click: sendTest }
      ]
    },
    {
      label: 'Ayarlar',
      submenu: [
        chk('Windows ile başlat', 'startWithWindows'),
        chk('Başlangıçta küçültülmüş (arka planda) aç', 'startMinimized'),
        chk('Pencereyi kapatınca arka planda çalışmaya devam et', 'closeToTray'),
        { type: 'separator' },
        chk('Giriş bilgilerimi hatırla (otomatik giriş)', 'autoLogin'),
        { label: savedUser ? 'Kayıtlı kullanıcı: ' + savedUser : 'Kayıtlı giriş bilgisi yok', enabled: false },
        { label: 'Kayıtlı giriş bilgisini sil', enabled: !!savedUser, click: deleteCreds }
      ]
    },
    {
      label: 'Güncelleme',
      submenu: [
        { label: 'Güncellemeleri denetle', accelerator: 'Ctrl+U', click: manualUpdate },
        { type: 'separator' },
        { label: `Program sürümü: v${localAppVersion()}` + (current ? `   Script sürümü: v${current.version}` : ''), enabled: false }
      ]
    }
  ]));
}

let updating = false;
async function manualUpdate() {
  if (updating) return;
  updating = true;
  try {
    await createSplash();
    const r = await runUpdateCheck(CHECK_MS);
    closeSplash();
    if (r === 'relaunch') return;
    buildMenu(); // surum bilgisi guncellensin
    if (win && !win.isDestroyed() && updateState.scriptsUpdated) win.reload();
  } finally { updating = false; }
}

// ================== BASLANGIC ==================
app.on('before-quit', () => { quitting = true; });
app.on('second-instance', () => showMain());

// Baslat menusu / masaustu / gorev cubugu / Windows bildirimleri icin kisayollar (AppUserModelID + ikon + ad)
function ensureShortcuts() {
  if (process.platform !== 'win32') return;
  const opts = { target: process.execPath, cwd: ROOT, args: '"' + ROOT + '"', description: APP_NAME, appUserModelId: 'com.karel.santral' };
  const ic = iconPath();
  if (ic) { opts.icon = ic; opts.iconIndex = 0; }
  try {
    const start = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', APP_NAME + '.lnk');
    shell.writeShortcutLink(start, 'create', opts);
  } catch (e) { log('Başlat menüsü kısayolu yazılamadı: ' + e.message); }
  try {
    const desk = path.join(app.getPath('desktop'), APP_NAME + '.lnk');
    if (fs.existsSync(desk)) shell.writeShortcutLink(desk, 'create', opts); // sadece varsa yenile
  } catch (e) { log('Masaüstü kısayolu yenilenemedi: ' + e.message); }
}

app.whenReady().then(async () => {
  loadSettings();
  applyLoginItem(); // klasor tasinsa da Windows ile baslatma yolu guncel kalsin
  ensureShortcuts();
  { const c = loadCreds(); if (c) savedUser = c.u || '(kullanıcı adı yok)'; }
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  session.defaultSession.setPermissionCheckHandler(() => true);

  const hidden = process.argv.includes('--hidden'); // Windows ile başlayınca sessiz aç
  if (!hidden) await createSplash();

  // Acilis ekrani: 5 sn guncelleme kontrolu (guncelleme varsa indirir, program yenilendiyse yeniden baslar)
  if (await runUpdateCheck(hidden ? 0 : CHECK_MS) === 'relaunch') return;

  buildMenu();
  createMain(hidden);
  createTray();
});
