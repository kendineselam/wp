@echo off
cd /d "%~dp0"
title Karel Santral
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur.ps1"
if errorlevel 1 (
  echo.
  echo Bir sorun olustu. Kayit dosyasi aciliyor: kurulum-log.txt
  start "" notepad "%~dp0kurulum-log.txt"
  pause
  exit /b 1
)
exit /b 0
